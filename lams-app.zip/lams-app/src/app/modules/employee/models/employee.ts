export interface Employee {
  employeeId: number;
  hireDate: Date;
  name: string;
  email: string;
  department: string;
  jobTitle: string;
  password: string;
}