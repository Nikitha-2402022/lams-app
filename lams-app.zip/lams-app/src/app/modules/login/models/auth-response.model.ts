// src/app/models/auth-response.model.ts
export interface AuthResponse {
    token: string; // The backend returns a field named 'token'
    employeeId:number;
  }