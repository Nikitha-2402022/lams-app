export interface LeaveBalanceDTO {
  leaveBalanceId?: number; 
    employeeId: number;
    name?: string;
    leaveType: string;
    balance: number;
  }